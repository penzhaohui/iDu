Form validation for JSON-like data (i.e. document) in Python.


