A serializer for JSON-like data in Python.


