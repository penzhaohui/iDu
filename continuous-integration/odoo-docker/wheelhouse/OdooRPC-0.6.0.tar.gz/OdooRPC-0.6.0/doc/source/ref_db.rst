odoorpc.db
==========

.. automodule:: odoorpc.db
    :members:
