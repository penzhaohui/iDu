odoorpc.error
=============

.. automodule:: odoorpc.error
    :members:

