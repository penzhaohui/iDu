odoorpc.models
==============

.. automodule:: odoorpc.models

.. autoclass:: odoorpc.models.Model
    :members:
    :special-members:
    :exclude-members: __hash__, __metaclass__
