odoorpc.report
==============

.. automodule:: odoorpc.report
    :members:
