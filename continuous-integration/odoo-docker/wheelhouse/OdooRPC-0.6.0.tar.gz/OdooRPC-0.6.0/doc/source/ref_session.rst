odoorpc.session
===============

.. automodule:: odoorpc.session
    :members:
