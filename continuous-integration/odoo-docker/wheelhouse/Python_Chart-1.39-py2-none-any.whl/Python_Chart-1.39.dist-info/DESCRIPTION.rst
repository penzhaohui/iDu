NOTE: I changed the email just to be able to upload it at pypi
but this project is copyright by Yasushi Saito <yasushi@cs.washington.edu>
Pychart is a Python library for creating high-quality
charts in Postscript, PDF, PNG, and SVG. 
It produces line plots, bar plots, range-fill plots, and pie
charts.

