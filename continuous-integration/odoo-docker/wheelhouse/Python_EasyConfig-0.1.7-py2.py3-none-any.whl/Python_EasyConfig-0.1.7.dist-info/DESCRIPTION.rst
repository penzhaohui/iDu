A simple library for loading configurations easily in Python, inspired by `flask.config`.


