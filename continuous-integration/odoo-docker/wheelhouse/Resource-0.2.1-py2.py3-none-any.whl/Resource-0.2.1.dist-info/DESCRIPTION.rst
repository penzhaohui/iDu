A Python library concentrated on the Resource layer of RESTful APIs.


