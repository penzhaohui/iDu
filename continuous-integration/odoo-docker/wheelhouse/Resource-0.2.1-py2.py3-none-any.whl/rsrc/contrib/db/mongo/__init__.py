#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .view import Collection
from .serializer import serializer
