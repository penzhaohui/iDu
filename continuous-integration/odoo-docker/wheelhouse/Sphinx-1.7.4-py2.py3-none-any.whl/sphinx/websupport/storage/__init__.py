# -*- coding: utf-8 -*-
"""
    sphinx.websupport.storage
    ~~~~~~~~~~~~~~~~~~~~~~~~~

    Storage for the websupport package.

    :copyright: Copyright 2007-2018 by the Sphinx team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""

from sphinxcontrib.websupport.storage import StorageBackend  # NOQA
