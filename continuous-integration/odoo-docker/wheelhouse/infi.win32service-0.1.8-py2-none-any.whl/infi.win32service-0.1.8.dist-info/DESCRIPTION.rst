Python bindings to Windows ServiceControlManager


