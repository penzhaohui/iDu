Source code documentation
=========================

Templating
~~~~~~~~~~

.. automodule:: py3o.template.main
    :members:

Data extraction
~~~~~~~~~~~~~~~

AST Conversion
--------------

.. automodule:: py3o.template.helpers
    :members:

Data structure
--------------

.. automodule:: py3o.template.data_struct
    :members:
