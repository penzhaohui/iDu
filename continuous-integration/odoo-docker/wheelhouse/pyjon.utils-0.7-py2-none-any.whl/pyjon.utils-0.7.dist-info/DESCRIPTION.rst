Introduction
============

Useful tools library with classes to do singletons, dynamic function pointers...

Python 3 support
================

We have just added python 3 support, but the Singleton metaclass does
 not work yet. You should not use the Singleton with python3


