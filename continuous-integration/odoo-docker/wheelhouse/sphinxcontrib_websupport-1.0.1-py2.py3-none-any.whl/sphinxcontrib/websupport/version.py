# -*- coding: utf-8 -*-
"""
    sphinxcontrib.websupport.version
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    :copyright: Copyright 2007-2017 by the Sphinx team, see README.
    :license: BSD, see LICENSE for details.
"""

__version__ = '1.0.1'
__version_info__ = tuple(map(int, __version__.split('.')))
